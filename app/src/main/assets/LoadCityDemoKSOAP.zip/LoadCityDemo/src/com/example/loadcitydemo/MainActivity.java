package com.example.loadcitydemo;

import java.io.IOException;
import java.util.ArrayList;
import org.apache.http.client.HttpResponseException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

	ListView lv_city_list;
	CityAdapter mAdapter;
	ArrayList<CityList> FetchCityList;
	
	private String CITY_NAME = "city";
	private String NAMESPACE = "http://tempuri.org/";
	private String METHOD_NAME = "LoadCity";
	private String SOAP_ACTION = "http://tempuri.org/LoadCity";
	private String CITY_URL = "http://krykey.com/krykey.asmx";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		lv_city_list = (ListView)findViewById(R.id.main_lv_city_list);
	
		FetchCityList = new ArrayList<CityList>();
		new fetchCityListAsyn().execute();	
	}

	public class fetchCityListAsyn extends AsyncTask<String, Void, String>
	{
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
						
			SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
			SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11); 
			envelope.dotNet = true;
			envelope.setOutputSoapObject(request);  
            
            HttpTransportSE httpTransport = new HttpTransportSE(CITY_URL);
            
            try {
                httpTransport.call(SOAP_ACTION, envelope);
                SoapPrimitive response = (SoapPrimitive)envelope.getResponse();
                System.out.println("Results : " +response.toString());
				String result = response.toString();
            
				if(result != null)
				{	
				 try {
					JSONArray cityList = new JSONArray(result);

					for (int i = 0; i < cityList.length(); i++) 
					{
						CityList myList = new CityList();
					    JSONObject JsonData = cityList.getJSONObject(i);
					     
					    myList.setName(JsonData.getString(CITY_NAME));            	  
					    FetchCityList.add(myList);
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					System.out.println("Error!!!"+e.getMessage());
				}
			  }else {
				Toast.makeText(getApplicationContext(), 
							"No Record Found!", Toast.LENGTH_SHORT).show();
			  }
           } catch (HttpResponseException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
           } catch (IOException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
           } catch (XmlPullParserException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
           }                
			return null;
		}
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			System.out.println("Data " +FetchCityList.size()+"");
			mAdapter = new CityAdapter(getApplicationContext(), 0, FetchCityList);
			lv_city_list.setAdapter(mAdapter);
		}
	}
}
