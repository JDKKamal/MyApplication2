package com.example.loadcitydemo;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CityAdapter extends ArrayAdapter<CityList>{

	ArrayList<CityList> FetchCityList;
	LayoutInflater inflater;
	Context mContext;
	TextView txt_city;
	
	public CityAdapter(Context context, int resource, ArrayList<CityList> arraList) {
		super(context, 0, arraList);
		// TODO Auto-generated constructor stub
		
		this.mContext = context;
		this.FetchCityList = arraList;
	}

	public View getView(int position, View conView, ViewGroup parent)
	{
		CityList cityName = FetchCityList.get(position);
		
		inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		if(conView == null)
		{
			conView = inflater.inflate(R.layout.raw_city_list, parent, false);
			txt_city = (TextView)conView.findViewById(R.id.raw_txt_name);
		}
		
		txt_city.setText(cityName.getName());
		Typeface face = Typeface.createFromAsset(getContext().getAssets(), "fonts/DroidSans.ttf");
		txt_city.setTypeface(face);
		return conView;
		
	}
}
